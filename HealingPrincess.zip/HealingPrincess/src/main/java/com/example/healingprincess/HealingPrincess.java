package com.example.healingprincess;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.audience.Audience;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Ageable;
import org.bukkit.block.data.BlockData;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.spigotmc.event.entity.EntityDismountEvent;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Healing the Princess - Paper 1.21.1, requires GSit.
 */
public final class HealingPrincess extends JavaPlugin implements Listener, TabExecutor {

    // ------------------------------------------------------------------ types
    enum Role {
        KNIGHT("Knight"), SEER("Seer"), IMPOSTOR("Impostor"), HELPER("Impostor Helper");
        final String label;
        Role(String label) { this.label = label; }
        boolean traitor() { return this == IMPOSTOR || this == HELPER; }
    }

    enum State { IDLE, INTRO, NOMINATING, VOTING, EXPEDITION, RESOLVING, ASSASSINATION }

    // Per material (index 0..2)
    private static final int[] TEAM_SIZE = {2, 3, 2};
    private static final int[] MAX_ROUNDS = {2, 2, 1};
    private static final int[] SABOTAGE_NEEDED = {1, 2, 1};

    // ------------------------------------------------------------------ state
    private NamespacedKey itemKey;

    private State state = State.IDLE;
    private final Map<UUID, Role> roles = new LinkedHashMap<>();
    private List<UUID> order = new ArrayList<>();
    private int leaderIdx;
    private int material;      // 0-based
    private int round;         // 1-based inside the material
    private int collected;

    private final Set<UUID> picks = new LinkedHashSet<>();
    private final List<UUID> team = new ArrayList<>();
    private final Map<UUID, Boolean> votes = new HashMap<>();
    private final Set<UUID> sabotaged = new HashSet<>();
    private boolean resolving;
    private UUID guess;

    private final Set<UUID> seated = new HashSet<>();
    private final Set<UUID> lookDown = new HashSet<>();

    private final Map<Block, BlockData> plantOriginal = new LinkedHashMap<>();
    private final Set<Block> remainingPlants = new HashSet<>();

    private final List<BukkitTask> tasks = new ArrayList<>();
    private BukkitTask voteTask;
    private BukkitTask expTask;

    // ------------------------------------------------------------- lifecycle
    @Override
    public void onEnable() {
        saveDefaultConfig();
        itemKey = new NamespacedKey(this, "hp_item");
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("hp");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        if (state != State.IDLE) stopGame(null);
    }

    // --------------------------------------------------------------- helpers
    private static Component c(String s, NamedTextColor col) { return Component.text(s, col); }

    private void say(Player p, String s, NamedTextColor col) { p.sendMessage(c("[HP] ", NamedTextColor.LIGHT_PURPLE).append(c(s, col))); }

    private void announce(String s, NamedTextColor col) { Bukkit.broadcast(c("[HP] ", NamedTextColor.LIGHT_PURPLE).append(c(s, col))); }

    private void later(long ticks, Runnable r) { tasks.add(Bukkit.getScheduler().runTaskLater(this, r, ticks)); }

    private List<Player> participants() {
        return roles.keySet().stream().map(Bukkit::getPlayer).filter(Objects::nonNull).collect(Collectors.toList());
    }

    private boolean isTraitor(UUID id) { Role r = roles.get(id); return r != null && r.traitor(); }

    private String nameOf(UUID id) {
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n != null ? n : id.toString().substring(0, 8);
    }

    private Player leader() { return Bukkit.getPlayer(order.get(leaderIdx)); }

    private ItemStack tagged(Material m, Component name, String tag) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, tag);
        it.setItemMeta(meta);
        return it;
    }

    private boolean isTag(ItemStack it, String tag) {
        if (it == null || !it.hasItemMeta()) return false;
        return tag.equals(it.getItemMeta().getPersistentDataContainer().get(itemKey, PersistentDataType.STRING));
    }

    private void removeTagged(String tag) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            PlayerInventory inv = p.getInventory();
            for (int i = 0; i < inv.getSize(); i++) {
                if (isTag(inv.getItem(i), tag)) inv.setItem(i, null);
            }
        }
    }

    // ---------------------------------------------------- lock / sit helpers
    private void lock(Player p, int ticks) {
        p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, ticks, 1, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, 10, false, false, false));
        p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, ticks, 128, false, false, false));
    }

    private void unlock(Player p) {
        p.removePotionEffect(PotionEffectType.BLINDNESS);
        p.removePotionEffect(PotionEffectType.SLOWNESS);
        p.removePotionEffect(PotionEffectType.JUMP_BOOST);
    }

    /** Uses GSit's /gsit command so no compile-time API dependency is needed. */
    private void sit(Player p) {
        seated.add(p.getUniqueId());
        lookDown.add(p.getUniqueId());
        Bukkit.dispatchCommand(p, "gsit");
    }

    private void stand(Player p) {
        boolean was = seated.remove(p.getUniqueId());
        lookDown.remove(p.getUniqueId());
        if (was && p.isInsideVehicle()) p.leaveVehicle();
    }

    // -------------------------------------------------------------- commands
    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage(c("/hp <start|stop|pick|vote|guess>", NamedTextColor.YELLOW));
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "start" -> {
                if (!s.hasPermission("hp.admin")) { s.sendMessage(c("No permission.", NamedTextColor.RED)); return true; }
                startGame(s);
            }
            case "stop" -> {
                if (!s.hasPermission("hp.admin")) { s.sendMessage(c("No permission.", NamedTextColor.RED)); return true; }
                if (state == State.IDLE) { s.sendMessage(c("No game is running.", NamedTextColor.RED)); return true; }
                stopGame("The game was stopped by an admin.");
            }
            case "pick" -> { if (s instanceof Player p) pick(p, a.length > 1 ? a[1] : null); }
            case "vote" -> {
                if (s instanceof Player p && a.length > 1) vote(p, a[1].equalsIgnoreCase("accept"));
            }
            case "guess" -> { if (s instanceof Player p && a.length > 1) guess(p, a[1]); }
            default -> s.sendMessage(c("/hp <start|stop|pick|vote|guess>", NamedTextColor.YELLOW));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 1) {
            List<String> l = new ArrayList<>(List.of("pick", "vote", "guess"));
            if (s.hasPermission("hp.admin")) { l.add("start"); l.add("stop"); }
            return l.stream().filter(x -> x.startsWith(a[0].toLowerCase())).toList();
        }
        if (a.length == 2) {
            if (a[0].equalsIgnoreCase("vote")) return List.of("accept", "reject");
            if (a[0].equalsIgnoreCase("pick") || a[0].equalsIgnoreCase("guess")) {
                return Bukkit.getOnlinePlayers().stream().map(Player::getName)
                        .filter(n -> n.toLowerCase().startsWith(a[1].toLowerCase())).toList();
            }
        }
        return List.of();
    }

    // ----------------------------------------------------------- game start
    private void startGame(CommandSender s) {
        if (state != State.IDLE) { s.sendMessage(c("A game is already running.", NamedTextColor.RED)); return; }
        List<Player> players = new ArrayList<>(Bukkit.getOnlinePlayers());
        int min = getConfig().getInt("settings.min-players", 4);
        if (players.size() < min) {
            s.sendMessage(c("Need at least " + min + " players.", NamedTextColor.RED));
            return;
        }
        Collections.shuffle(players);
        roles.clear();
        for (int i = 0; i < players.size(); i++) {
            Role r = i == 0 ? Role.SEER : i == 1 ? Role.IMPOSTOR : i == 2 ? Role.HELPER : Role.KNIGHT;
            roles.put(players.get(i).getUniqueId(), r);
        }
        order = new ArrayList<>(roles.keySet());
        Collections.shuffle(order); // seating order = "clockwise" order
        material = 0; round = 1; collected = 0; leaderIdx = 0;
        guess = null;
        state = State.INTRO;
        runIntro(players);
    }

    private void runIntro(List<Player> players) {
        // Phase 1: everybody sits, blind, slowed, looking down.
        for (Player p : players) {
            say(p, "You are the " + roles.get(p.getUniqueId()).label + ".", NamedTextColor.GOLD);
            sit(p);
            lock(p, 600); // 30 s
        }
        tasks.add(Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (UUID id : lookDown) {
                Player p = Bukkit.getPlayer(id);
                if (p != null) p.setRotation(p.getLocation().getYaw(), 90f);
            }
        }, 0L, 2L));

        // Phase 2 (5 s): Impostors wake up and see each other.
        later(100, () -> {
            List<Player> traitors = participants().stream().filter(p -> isTraitor(p.getUniqueId())).toList();
            for (Player t : traitors) {
                unlock(t);
                stand(t);
                String mates = traitors.stream().filter(o -> o != t).map(Player::getName).collect(Collectors.joining(", "));
                say(t, mates.isEmpty() ? "You have no teammate." : "Your teammate is: " + mates, NamedTextColor.RED);
            }
        });

        // Phase 3 (10 s): Impostors freeze standing, Seer wakes up for 7 s.
        later(200, () -> {
            for (Player p : participants()) {
                UUID id = p.getUniqueId();
                if (isTraitor(id)) {
                    lock(p, 300);
                    lookDown.add(id);
                } else if (roles.get(id) == Role.SEER) {
                    unlock(p);
                    stand(p);
                    say(p, "Look around: anyone STANDING is an Impostor. Anyone still sitting is a Knight.", NamedTextColor.AQUA);
                }
            }
        });

        // Phase 4 (17 s): everyone wakes up, first leader gets the book.
        later(340, this::beginGame);
    }

    private void beginGame() {
        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "effect clear @a");
        for (Player p : participants()) stand(p);
        seated.clear();
        lookDown.clear();
        leaderIdx = new Random().nextInt(order.size());
        announce("The ritual is over. The expedition begins!", NamedTextColor.GOLD);
        startNomination();
    }

    // ------------------------------------------------------------ nomination
    private void startNomination() {
        state = State.NOMINATING;
        picks.clear();
        votes.clear();
        removeTagged("book");
        Player leader = leader();
        if (leader == null) { stopGame("The leader left. Game stopped."); return; }
        leader.getInventory().addItem(tagged(Material.BOOK, c("Expedition Book", NamedTextColor.GOLD), "book"));
        announce("Material " + (material + 1) + "/3 (" + getConfig().getString("material-" + (material + 1) + ".name", "?")
                + "), attempt " + round + "/" + MAX_ROUNDS[material] + ". Leader: " + leader.getName()
                + ". Team size: " + TEAM_SIZE[material] + ".", NamedTextColor.YELLOW);
        sendPickList(leader);
    }

    private void sendPickList(Player leader) {
        Component line = c("Choose " + TEAM_SIZE[material] + " players (click to toggle): ", NamedTextColor.YELLOW);
        for (Player p : participants()) {
            line = line.append(Component.text("[" + p.getName() + "] ",
                            picks.contains(p.getUniqueId()) ? NamedTextColor.GREEN : NamedTextColor.GRAY)
                    .clickEvent(ClickEvent.runCommand("/hp pick " + p.getName())));
        }
        leader.sendMessage(line);
    }

    private void pick(Player p, String targetName) {
        if (state != State.NOMINATING || !p.getUniqueId().equals(order.get(leaderIdx))) {
            say(p, "You cannot nominate right now.", NamedTextColor.RED);
            return;
        }
        if (targetName == null) { sendPickList(p); return; }
        Player t = Bukkit.getPlayerExact(targetName);
        if (t == null || !roles.containsKey(t.getUniqueId())) { say(p, "Unknown player.", NamedTextColor.RED); return; }
        UUID id = t.getUniqueId();
        if (!picks.remove(id)) picks.add(id);
        if (picks.size() == TEAM_SIZE[material]) {
            startVote();
        } else {
            say(p, "Selected " + picks.size() + "/" + TEAM_SIZE[material] + ": "
                    + picks.stream().map(this::nameOf).collect(Collectors.joining(", ")), NamedTextColor.GREEN);
            sendPickList(p);
        }
    }

    // ---------------------------------------------------------------- voting
    private void startVote() {
        state = State.VOTING;
        votes.clear();
        String names = picks.stream().map(this::nameOf).collect(Collectors.joining(", "));
        announce(leader().getName() + " proposes: " + names, NamedTextColor.YELLOW);
        Component buttons = Component.text("Vote: ", NamedTextColor.YELLOW)
                .append(Component.text("[ACCEPT]", NamedTextColor.GREEN, TextDecoration.BOLD)
                        .clickEvent(ClickEvent.runCommand("/hp vote accept"))
                        .hoverEvent(HoverEvent.showText(c("Accept this team", NamedTextColor.GREEN))))
                .append(Component.text("  "))
                .append(Component.text("[REJECT]", NamedTextColor.RED, TextDecoration.BOLD)
                        .clickEvent(ClickEvent.runCommand("/hp vote reject"))
                        .hoverEvent(HoverEvent.showText(c("Reject this team", NamedTextColor.RED))));
        for (Player p : participants()) p.sendMessage(buttons);
        int timeout = getConfig().getInt("settings.vote-timeout-seconds", 45);
        voteTask = Bukkit.getScheduler().runTaskLater(this, this::resolveVote, timeout * 20L);
        tasks.add(voteTask);
    }

    private void vote(Player p, boolean accept) {
        if (state != State.VOTING || !roles.containsKey(p.getUniqueId())) return;
        votes.put(p.getUniqueId(), accept);
        say(p, "Your vote: " + (accept ? "ACCEPT" : "REJECT"), accept ? NamedTextColor.GREEN : NamedTextColor.RED);
        if (votes.size() >= participants().size()) resolveVote();
    }

    private void resolveVote() {
        if (state != State.VOTING) return;
        if (voteTask != null) voteTask.cancel();
        long yes = votes.values().stream().filter(b -> b).count();
        long no = votes.values().stream().filter(b -> !b).count();
        announce("Votes - ACCEPT: " + yes + " | REJECT: " + no, NamedTextColor.YELLOW);
        if (yes > no) {
            announce("The team is approved!", NamedTextColor.GREEN);
            team.clear();
            team.addAll(picks);
            startExpedition();
        } else {
            announce("The team is rejected. The Expedition Book passes on.", NamedTextColor.RED);
            leaderIdx = (leaderIdx + 1) % order.size();
            startNomination();
        }
    }

    // ------------------------------------------------------------ expedition
    private void startExpedition() {
        int n = material + 1;
        String base = "material-" + n;
        World world = Bukkit.getWorld(getConfig().getString(base + ".world", "world"));
        plantOriginal.clear();
        remainingPlants.clear();
        if (world != null) {
            for (Map<?, ?> m : getConfig().getMapList(base + ".plants")) {
                Block b = world.getBlockAt(num(m, "x"), num(m, "y"), num(m, "z"));
                plantOriginal.put(b, b.getBlockData());
                Object type = m.get("type");
                if (type != null) {
                    Material mat = Material.matchMaterial(String.valueOf(type));
                    if (mat == null || !mat.isBlock()) {
                        getLogger().warning("Unknown block type in " + base + ": " + type);
                        continue;
                    }
                    b.setType(mat, false);
                    if (b.getBlockData() instanceof Ageable ag) {
                        ag.setAge(ag.getMaximumAge());
                        b.setBlockData(ag);
                    }
                }
                remainingPlants.add(b);
            }
        }
        if (remainingPlants.isEmpty()) {
            stopGame("No valid plants configured for " + base + " (check config.yml). Game stopped.");
            return;
        }

        state = State.EXPEDITION;
        resolving = false;
        sabotaged.clear();

        ConfigurationSection spawn = getConfig().getConfigurationSection(base + ".team-spawn");
        Location tp = null;
        if (spawn != null && world != null) {
            tp = new Location(world, spawn.getDouble("x"), spawn.getDouble("y"), spawn.getDouble("z"),
                    (float) spawn.getDouble("yaw"), (float) spawn.getDouble("pitch"));
        }
        for (UUID id : team) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            p.getInventory().addItem(tagged(Material.STICK, c("Sabotage Tool", NamedTextColor.RED), "stick"));
            if (tp != null) p.teleport(tp);
            say(p, "You are on the expedition! Destroy the marked plants. Right-click your Sabotage Tool to sabotage.",
                    NamedTextColor.GOLD);
        }
        announce("Expedition team: " + team.stream().map(this::nameOf).collect(Collectors.joining(", "))
                + " - destroy " + remainingPlants.size() + " plant(s)!", NamedTextColor.GOLD);

        int timeout = getConfig().getInt("settings.expedition-timeout-seconds", 0);
        if (timeout > 0) {
            expTask = Bukkit.getScheduler().runTaskLater(this, this::resolveRound, timeout * 20L);
            tasks.add(expTask);
        }
    }

    private static int num(Map<?, ?> m, String key) {
        Object o = m.get(key);
        return o instanceof Number n ? n.intValue() : 0;
    }

    private void resolveRound() {
        if (state != State.EXPEDITION) return;
        state = State.RESOLVING;
        if (expTask != null) { expTask.cancel(); expTask = null; }

        boolean failed = sabotaged.size() >= SABOTAGE_NEEDED[material];
        removeTagged("stick");
        resetPlants();
        team.clear();

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showTitle(Title.title(
                    failed ? c("FAILED", NamedTextColor.RED) : c("SUCCESS", NamedTextColor.GREEN),
                    failed ? c("The expedition was sabotaged!", NamedTextColor.GRAY) : c("The expedition succeeded!", NamedTextColor.GRAY)));
        }

        if (!failed) collected++;
        boolean materialDone = !failed || round >= MAX_ROUNDS[material];
        if (materialDone) { material++; round = 1; } else { round++; }
        if (getConfig().getBoolean("settings.rotate-book-after-expedition", true)) {
            leaderIdx = (leaderIdx + 1) % order.size();
        }

        later(60, () -> {
            if (material >= 3) {
                if (collected >= getConfig().getInt("settings.materials-needed", 3)) startAssassination();
                else endGame(true, "The expeditions were sabotaged.");
            } else {
                startNomination();
            }
        });
    }

    private void resetPlants() {
        boolean restore = getConfig().getBoolean("settings.restore-original-blocks", false);
        Material reset = Material.matchMaterial(getConfig().getString("settings.reset-material", "AIR"));
        if (reset == null) reset = Material.AIR;
        for (Map.Entry<Block, BlockData> e : plantOriginal.entrySet()) {
            if (restore) e.getKey().setBlockData(e.getValue(), false);
            else e.getKey().setType(reset, false);
        }
        plantOriginal.clear();
        remainingPlants.clear();
    }

    // ---------------------------------------------------------- assassination
    private void startAssassination() {
        state = State.ASSASSINATION;
        guess = null;
        int secs = getConfig().getInt("settings.assassination-seconds", 30);
        announce("All materials collected! The Impostors have " + secs + " seconds to find the Seer...", NamedTextColor.GOLD);
        for (Player p : participants()) {
            if (isTraitor(p.getUniqueId())) {
                say(p, "Your chat is now private to your team. Use /hp guess <player> to name the Seer. The last guess counts.",
                        NamedTextColor.RED);
                p.sendMessage(Component.text("Candidates: ", NamedTextColor.YELLOW).append(candidateList()));
            }
        }
        later(secs * 20L, () -> {
            if (state != State.ASSASSINATION) return;
            if (guess != null && roles.get(guess) == Role.SEER) endGame(true, "The Impostors identified the Seer!");
            else endGame(false, "The Impostors failed to find the Seer.");
        });
    }

    private Component candidateList() {
        Component line = Component.empty();
        for (Player p : participants()) {
            if (isTraitor(p.getUniqueId())) continue;
            line = line.append(Component.text("[" + p.getName() + "] ", NamedTextColor.AQUA)
                    .clickEvent(ClickEvent.runCommand("/hp guess " + p.getName())));
        }
        return line;
    }

    private void guess(Player p, String targetName) {
        if (state != State.ASSASSINATION || !isTraitor(p.getUniqueId())) return;
        Player t = Bukkit.getPlayerExact(targetName);
        if (t == null || !roles.containsKey(t.getUniqueId())) { say(p, "Unknown player.", NamedTextColor.RED); return; }
        guess = t.getUniqueId();
        for (Player o : participants()) {
            if (isTraitor(o.getUniqueId())) say(o, p.getName() + " guesses the Seer is: " + t.getName(), NamedTextColor.RED);
        }
    }

    // --------------------------------------------------------------- the end
    private void endGame(boolean impostorsWin, String why) {
        String list = roles.entrySet().stream()
                .map(e -> nameOf(e.getKey()) + " = " + e.getValue().label)
                .collect(Collectors.joining(", "));
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showTitle(Title.title(
                    impostorsWin ? c("IMPOSTORS WIN", NamedTextColor.RED) : c("INNOCENTS WIN", NamedTextColor.GREEN),
                    c(why, NamedTextColor.GRAY)));
        }
        announce("Roles: " + list, NamedTextColor.YELLOW);
        stopGame(null);
    }

    private void stopGame(String reason) {
        tasks.forEach(BukkitTask::cancel);
        tasks.clear();
        voteTask = null;
        expTask = null;

        Set<UUID> wasSeated = new HashSet<>(seated);
        seated.clear();
        lookDown.clear();
        for (UUID id : roles.keySet()) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) continue;
            if (wasSeated.contains(id) && p.isInsideVehicle()) p.leaveVehicle();
            for (PotionEffect e : p.getActivePotionEffects()) p.removePotionEffect(e.getType());
        }
        removeTagged("stick");
        removeTagged("book");
        resetPlants();

        roles.clear();
        order = new ArrayList<>();
        picks.clear();
        team.clear();
        votes.clear();
        sabotaged.clear();
        guess = null;
        resolving = false;
        state = State.IDLE;
        if (reason != null) announce(reason, NamedTextColor.RED);
    }

    // ---------------------------------------------------------------- events
    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (state == State.IDLE) return;
        Player p = e.getPlayer();
        Block b = e.getBlock();

        if (state == State.EXPEDITION && !resolving && remainingPlants.contains(b)) {
            if (!team.contains(p.getUniqueId())) {
                e.setCancelled(true);
                say(p, "Only the expedition team may destroy these plants.", NamedTextColor.RED);
                return;
            }
            e.setDropItems(false);
            remainingPlants.remove(b);
            boolean all = getConfig().getBoolean("settings.require-all-plants", true);
            if (!all || remainingPlants.isEmpty()) {
                // Freeze sabotage clicks right now; evaluate on the next tick (block is gone by then).
                resolving = true;
                Bukkit.getScheduler().runTask(this, this::resolveRound);
            } else {
                announce(remainingPlants.size() + " plant(s) left.", NamedTextColor.YELLOW);
            }
            return;
        }
        if (getConfig().getBoolean("settings.protect-blocks", true)
                && !(p.getGameMode() == GameMode.CREATIVE && p.hasPermission("hp.admin"))) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        if (!isTag(e.getItem(), "stick")) return;
        e.setCancelled(true);

        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (state != State.EXPEDITION || resolving || !team.contains(id)) return;
        // Knights: nothing happens. Impostors: one sabotage click per round.
        if (isTraitor(id) && sabotaged.add(id)) {
            p.sendActionBar(c("Sabotage registered.", NamedTextColor.RED));
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        ItemStack it = e.getItemDrop().getItemStack();
        if (isTag(it, "stick") || isTag(it, "book")) e.setCancelled(true);
    }

    @EventHandler
    public void onDismount(EntityDismountEvent e) {
        if (e.getEntity() instanceof Player p && seated.contains(p.getUniqueId())) e.setCancelled(true);
    }

    @EventHandler
    public void onSneak(PlayerToggleSneakEvent e) {
        if (seated.contains(e.getPlayer().getUniqueId())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onChat(AsyncChatEvent e) {
        if (state != State.ASSASSINATION || !isTraitor(e.getPlayer().getUniqueId())) return;
        // Impostor chat is private during the assassination phase.
        e.viewers().removeIf(aud -> aud instanceof Player pl && !isTraitor(pl.getUniqueId()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        if (state != State.IDLE && roles.containsKey(e.getPlayer().getUniqueId())) {
            stopGame(e.getPlayer().getName() + " left the game. Game stopped.");
        }
    }
}
